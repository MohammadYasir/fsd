/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.metallica.fsd.notifyservice;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

/**
 *
 * @author myasir
 */
@Service
public class Receiver {
    @RabbitListener(queues = NotificationServiceApplication.QUEUE_GENERIC_NAME)
    public void receiveMessage(String message) {
        System.out.println("Received <" + message + ">");
    }
}
